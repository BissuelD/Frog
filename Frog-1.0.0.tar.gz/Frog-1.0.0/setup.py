import setuptools

setuptools.setup(
    name="Frog",
    version="1.0.0",
    author="Guillaume Le Breton",
    author_email="guillaume_le_breton@live.fr",
    description="FROm molecular dynamics to second harmonic Generation",
    url="https://cameleon.univ-lyon1.fr/glebreton/frog",
    zip_safe=False,
    packages=setuptools.find_packages(),
    entry_points={"console_scripts": ["Frog=Frog.main:frog_run_from_shell"]},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU GPLv3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=['numpy', 'MDAnalysis', 'pytim'],
)


